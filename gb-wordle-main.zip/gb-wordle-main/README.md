# gb-wordle

A WORDLE clone for the Nintendo Game Boy!

You can play it online [here](https://nezza.github.io/gbwordle/)!

Or download ready-made ROMs [here](https://nezza.github.io/gbwordle/roms.html)!

This ROM was build using the awesome GBDK!

